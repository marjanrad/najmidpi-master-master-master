package com.example.najmidpi.server.model;

public class ResponseSensor {
    String test;

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }
}
